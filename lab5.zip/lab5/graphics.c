#include "graphics.h"

uint8_t *video_mem;
vbe_mode_info_t info_mode;
struct minix_mem_range memory_range;
uint8_t bytes_per_pixel;

unsigned int vram_base;
unsigned int vram_size;
int r;

int set_video_mem(uint16_t mode){
  memset(&info_mode, 0, sizeof(info_mode));

  if(vbe_get_mode_info(mode, &info_mode) != 0){
    printf("vbe_get_mode_info() -> error getting video mode\n");
    return 1;
  }

  int hres = info_mode.XResolution;
  int vres = info_mode.YResolution;
  int bits_per_pixel = info_mode.BitsPerPixel;
  bytes_per_pixel = (bits_per_pixel+7)/8;

  vram_base = info_mode.PhysBasePtr;
  vram_size = hres*vres*bytes_per_pixel;

  memory_range.mr_base = info_mode.PhysBasePtr;
  memory_range.mr_limit = memory_range.mr_base + vram_size;

  if( OK != (r = sys_privctl(SELF, SYS_PRIV_ADD_MEM, &memory_range)))
    panic("sys_privctl (ADD_MEM) failed: %d\n", r);

  video_mem = vm_map_phys(SELF, (void *)memory_range.mr_base, vram_size);

  if(video_mem == MAP_FAILED){
    panic("couldn't map video memory");
  }

  return 0;
}

int set_graphics_mode(uint16_t submode){
  reg86_t r86;
  memset(&r86, 0, sizeof(r86));

  r86.intno = 0x10;
  r86.ah = 0x4F;
  r86.al = 0x02; 

  r86.ax = 0x4F02;
  r86.bx = submode | BIT(14);

  if( sys_int86(&r86) != OK ) {
    printf("\tvg_exit(): sys_int86() failed \n");
    return 1;
  }
  return 0;
}

uint32_t pixel_index(uint16_t x, uint16_t y) {
    return y * info_mode.XResolution + x;
}

uint32_t frame_buffer_index(uint16_t x, uint16_t y) {
    return pixel_index(x, y) * bytes_per_pixel;    
}

int draw_pixel(uint16_t x, uint16_t y, uint32_t color){
  if ((x >= info_mode.XResolution) || (y >=info_mode.YResolution)){
    return 1;
  } 
  unsigned int index = frame_buffer_index(x,y);
  if(memcpy(&video_mem[index], &color,bytes_per_pixel) == NULL) return 1;
  return 0;

}
int (draw_hline)(uint16_t x, uint16_t y, uint16_t len, uint32_t color){
  uint16_t x_initial = x;
  while(x < x_initial + len){
    if(draw_pixel(x,y,color)) return 1;
    x++;
  }
  return 0;
}

int (draw_rectangle)(uint16_t x, uint16_t y, uint16_t width, uint16_t height, uint32_t color){
  uint16_t y_initial = y;
  while(y < y_initial + height){
    if(draw_hline(x,y,width,color)) return 1;
    y++;
  }
  return 0;
}


uint8_t(get_rgb_component)(uint32_t color, uint8_t size, uint8_t position){
  uint32_t mask = BIT(size) - 1;
  uint8_t result = (uint8_t)((color >> position) & mask);
  return result;
}


int(print_xpm)(xpm_map_t xpm, uint16_t x, uint16_t y) {
  xpm_image_t img;
  uint8_t *colors = xpm_load(xpm, XPM_INDEXED, &img);
  if (colors == NULL) return 1;

  for (int h = 0 ; h < img.height ; h++) {
    for (int w = 0 ; w < img.width ; w++) {
      if (draw_pixel(x + w, y + h, *colors) != 0) return 1;
      colors++;
    }
  }
  return 0;
}
