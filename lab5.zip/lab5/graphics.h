#include <lcom/lcf.h>
#include <stdint.h>
#include "vbe.h"

int (set_graphics_mode)(uint16_t submode);
int (set_video_mem)(uint16_t submode);
uint32_t (pixel_index)(uint16_t x, uint16_t y);
uint32_t (frame_buffer_index)(uint16_t x, uint16_t y);
int (draw_pixel)(uint16_t x, uint16_t y, uint32_t color);
int (draw_hline)(uint16_t x, uint16_t y, uint16_t len, uint32_t color);
int (draw_rectangle)(uint16_t x, uint16_t y, uint16_t width, uint16_t height, uint32_t color);
uint8_t(get_rgb_component)(uint32_t color, uint8_t size, uint8_t position);
int (print_xpm)(xpm_map_t xpm, uint16_t x, uint16_t y);
