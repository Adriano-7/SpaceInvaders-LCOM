// IMPORTANT: you must include the following line in all your C files
#include <lcom/lcf.h>

#include <lcom/lab5.h>

#include <stdint.h>
#include <stdio.h>

#include "graphics.h"
#include "keyboard.h"

extern uint8_t output;
extern vbe_mode_info_t info_mode;

// Any header files included below this line should have been created by you

int main(int argc, char *argv[]) {
  // sets the language of LCF messages (can be either EN-US or PT-PT)
  lcf_set_language("EN-US");

  // enables to log function invocations that are being "wrapped" by LCF
  // [comment this out if you don't want/need it]
  lcf_trace_calls("/home/evans24/Desktop/LCOM/MINIX-LCOM/shared/g5/lab5/trace.txt");

  // enables to save the output of printf function calls on a file
  // [comment this out if you don't want/need it]
  lcf_log_output("/home/evans24/Desktop/LCOM/MINIX-LCOM/shared/g5/lab5/output.txt");

  // handles control over to LCF
  // [LCF handles command line arguments and invokes the right function]
  if (lcf_start(argc, argv))
    return 1;

  // LCF clean up tasks
  // [must be the last statement before return]
  lcf_cleanup();

  return 0;
}

int(video_test_init)(uint16_t mode, uint8_t delay) {
  if(set_graphics_mode(mode)){
    printf("video_test_init() -> Error setting graphics mode\n");
    return 1;
  }

  sleep(delay);

  if(vg_exit()){
    printf("vg_exit() -> Error returning to text mode\n");
    return 1;
  }
  return 0;
}

int(video_test_rectangle)(uint16_t mode, uint16_t x, uint16_t y,
                          uint16_t width, uint16_t height, uint32_t color) {

  if(set_video_mem(mode)) return 1;
  if(set_graphics_mode(mode)) return 1;
  if(draw_rectangle(x,y,width,height,color)) return 1;
  
  int ipc_status, r;
  message msg;
  uint8_t keyboard_bit_no;

  if(keyboard_subscribe_interrupts(&keyboard_bit_no)){
    printf("kbd_test_scan() -> Error subscribing keyboard interrupts\n");
    return 1;
  }
  do {
      if ((r = driver_receive(ANY, &msg, &ipc_status)) != 0) {
        printf("driver_receive failed with %d", r);
      }
      if (is_ipc_notify(ipc_status)) {
        switch(_ENDPOINT_P(msg.m_source)) {
          case HARDWARE:
            if (msg.m_notify.interrupts & BIT(keyboard_bit_no)) {
              kbc_ih();  
            }
            break;
          default:
            break;
        }
      }
    } while (output != 0x81);

  if(keyboard_unsubscribe_interrupts()){
    printf("kbd_test_scan() -> Error unsubscribing keyboard interrupt's\n");
    return 1;
  }

  if(vg_exit()) return 1;
  return 0;
}

int(video_test_pattern)(uint16_t mode, uint8_t no_rectangles, uint32_t first, uint8_t step) {
  if(set_video_mem(mode)) return 1;
  if(set_graphics_mode(mode)) return 1;

  unsigned width = info_mode.XResolution /no_rectangles;
  unsigned height = info_mode.YResolution / no_rectangles;

  for (int i = 0; i < no_rectangles; i++){
    for (int j = 0; j < no_rectangles; j++){

      uint32_t color;
      
      if(mode == 0x105){
        color = (first + (i * no_rectangles + j) * step) % (1 << info_mode.BitsPerPixel);
      }else{
        uint8_t red_first = get_rgb_component(first, info_mode.RedMaskSize, info_mode.RedFieldPosition);
        uint8_t green_first = get_rgb_component(first, info_mode.GreenMaskSize, info_mode.GreenFieldPosition);
        uint8_t blue_first = get_rgb_component(first, info_mode.BlueMaskSize, info_mode.BlueFieldPosition);

        uint8_t red = (red_first + j * step) % (1 << info_mode.RedMaskSize);
        uint8_t green = (green_first + i * step) % (1 << info_mode.GreenMaskSize);
        uint8_t blue = (blue_first + (i + j) * step) % (1 << info_mode.BlueMaskSize);

        color = (red << info_mode.RedFieldPosition) | (green << info_mode.GreenFieldPosition) | (blue << info_mode.BlueMaskSize);
      }
      
      if(draw_rectangle(i*width, j*height, width, height, color)) return 1;
    }
  }


  int ipc_status, r;
  message msg;
  uint8_t keyboard_bit_no;

  if(keyboard_subscribe_interrupts(&keyboard_bit_no)){
    printf("kbd_test_scan() -> Error subscribing keyboard interrupts\n");
    return 1;
  }
  do {
      if ((r = driver_receive(ANY, &msg, &ipc_status)) != 0) {
        printf("driver_receive failed with %d", r);
      }
      if (is_ipc_notify(ipc_status)) {
        switch(_ENDPOINT_P(msg.m_source)) {
          case HARDWARE:
            if (msg.m_notify.interrupts & BIT(keyboard_bit_no)) {
              kbc_ih();  
            }
            break;
          default:
            break;
        }
      }
    } while (output != 0x81);

  if(keyboard_unsubscribe_interrupts()){
    printf("kbd_test_scan() -> Error unsubscribing keyboard interrupt's\n");
    return 1;
  }

  if(vg_exit()) return 1;
  return 0;
}

int(video_test_xpm)(xpm_map_t xpm, uint16_t x, uint16_t y) {

  if(set_video_mem(0x105)) return 1;
  if(set_graphics_mode(0x105)) return 1;
  if(print_xpm(xpm, x, y)) return 1;

  int ipc_status, r;
  message msg;
  uint8_t keyboard_bit_no;

  if(keyboard_subscribe_interrupts(&keyboard_bit_no)){
    printf("kbd_test_scan() -> Error subscribing keyboard interrupts\n");
    return 1;
  }
  do {
      if ((r = driver_receive(ANY, &msg, &ipc_status)) != 0) {
        printf("driver_receive failed with %d", r);
      }
      if (is_ipc_notify(ipc_status)) {
        switch(_ENDPOINT_P(msg.m_source)) {
          case HARDWARE:
            if (msg.m_notify.interrupts & BIT(keyboard_bit_no)) {
              kbc_ih();  
            }
            break;
          default:
            break;
        }
      }
    } while (output != 0x81);

  if(keyboard_unsubscribe_interrupts()){
    printf("kbd_test_scan() -> Error unsubscribing keyboard interrupt's\n");
    return 1;
  }

  if(vg_exit()) return 1;
  return 0;
}

int(video_test_move)(xpm_map_t xpm, uint16_t xi, uint16_t yi, uint16_t xf, uint16_t yf,
                     int16_t speed, uint8_t fr_rate) {


  return 1;
}

int(video_test_controller)() {
  printf("%s(): under construction\n", __func__);

  return 1;
}
